<template>
  <div>
    <Heading></Heading>
    <Nav></Nav>
    <v-container>
      <h1>Home</h1>
    </v-container>
    <Footing></Footing>
  </div>
  
</template>

<script>

import Heading from '../components/Heading'
import Nav from "../components/Nav"
import Footing from "../components/Footing"

export default {
  name: 'HomeView',

  components: {
    Heading,
    Nav,
    Footing
  }
}
</script>
