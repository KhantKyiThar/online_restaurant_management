<template>
  <div class="login">
    <Heading></Heading>
    <Nav></Nav>
    <h1>This is an Login page</h1>
  </div>
</template>

<script>
import Heading from "../components/Heading"
import Nav from "../components/Nav"
// import HelloWorld from "../components/HelloWorld";

export default {
  name: "Login",
  components: {
    Heading,
    Nav
  }
}
</script>
