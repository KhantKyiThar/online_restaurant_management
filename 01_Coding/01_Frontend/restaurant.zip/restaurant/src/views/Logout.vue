<template>
  <div class="logout">
    <Heading></Heading>
    <Nav></Nav>
    <h1>This is an Logout page</h1>
  </div>
</template>

<script>
import Heading from "../components/Heading"
import Nav from "../components/Nav"


export default {
  name: "Logout",
  components: {
    Heading,
    Nav
  }
}
</script>
