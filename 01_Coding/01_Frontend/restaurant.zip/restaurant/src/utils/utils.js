import constant from "./Constant";
import http from "./http";

export default { constant, http };