const localDomain="http://localhost:8085/api";

export default { localDomain };