<template>
    <v-container>
        <!-- <router-link to="/">Home</router-link> -->
        <ul class="nav navbar-nav">
            <router-link tag="li" active-class="active" to="/"><a>Home</a></router-link>
            <router-link tag="li" active-class="active" to="/soup"><a>Soup</a></router-link>
            <router-link tag="li" active-class="active" to="/vegetables"><a>Vegetables</a></router-link>
        </ul>
    </v-container>
</template>

<script>
  export default {
    name: "Nav",
    // data: () => ({
    //   items: [
    //     {
    //       text: 'Soup',
    //       disabled: false,
    //       href: 'soup',
    //     },
    //     {
    //       text: 'Meat',
    //       disabled: false,
    //       href: 'meat',
    //     },
    //     {
    //       text: 'Vegetables',
    //       disabled: false,
    //       href: 'vegetables',
    //     },
    //   ],
    // }),
  }
</script>

<style>
  ul.nav {
    list-style-type: none !important;
    display: flex;
    padding-left: 0 !important;
  }
  .nav li {
    padding: 0 20px;
  }
  .nav li a {
    text-decoration: none;
    color: #ec407a !important;
  }
  nav li:hover,
  nav li:active {
    background-color: indianred;
    cursor: pointer;
  }
</style>

