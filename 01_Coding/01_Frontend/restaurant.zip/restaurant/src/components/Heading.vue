<template>
    <v-app-bar app color="pink lighten-1" dense dark>
        <a class="logoTitle" href="/">1 Gigabye</a>

        <v-spacer></v-spacer>
        <!-- Admin -->
        <router-link class="mx-2 navlink" to="/admin">Admin</router-link>

        <!-- Staff -->
        <router-link class="mx-2 navlink" to="/staff">Staff</router-link>

        <!-- Login -->
        <!-- <span v-if="!isLogin">|</span> -->
        <router-link v-if="!isLogin" class="mx-2 navlink" to="/login">Login</router-link>

        <!-- Login out -->
        <!-- <span v-if="isLogin">|</span> -->
        <a v-if="isLogin" class="mx-2 navlink" @click="logout()">Logout</a>

    </v-app-bar>
    
</template>

<script>
export default {
    name: "heading",
    data: () => ({
        isLogin: false,
    }),
    created() {
        // IsLogin
        this.isLogin = this.$store.state.isLogin;
        this.$store.watch(
        () => {
            return this.$store.state.isLogin;
        },
        (newVal, oldVal) => {
            this.isLogin = newVal;
        },
        {
            deep: true,
        }
        );
    }
}
</script>

<style>
    a.logoTitle {
        color: #fff !important;
        text-decoration: none;
        font-size: 24px;
        display: inline-block;
        margin-left: 30px;
    }
    .navlink {
        color: #fff !important;
        text-decoration: none;
    }

    .navlink:hover {
        cursor: pointer;
        text-decoration: underline;
    }
</style>