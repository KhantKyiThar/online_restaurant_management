package com.javaclass.restaurant.entity;

public enum Gender {
	Male, Female
}
