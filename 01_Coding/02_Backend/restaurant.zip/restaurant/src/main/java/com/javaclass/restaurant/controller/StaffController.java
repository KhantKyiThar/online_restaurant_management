package com.javaclass.restaurant.controller;

public class StaffController {

}
