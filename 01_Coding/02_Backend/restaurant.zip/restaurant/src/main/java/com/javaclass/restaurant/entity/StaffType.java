package com.javaclass.restaurant.entity;

public enum StaffType {
	Admin, Manager, Staff
}
