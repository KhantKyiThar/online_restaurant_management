package com.javaclass.restaurant.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryController {
	
}
